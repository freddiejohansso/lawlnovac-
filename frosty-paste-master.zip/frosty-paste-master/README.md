perfecthook

shitty paste, someone got ratted or something and is passing out source so here it is

